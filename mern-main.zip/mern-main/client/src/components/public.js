import React, { Component } from 'react';

export default class Public extends Component {
  render() {
    return (
      <div>
      <h1>Public</h1>
      </div>
    );
  }
}
