## To Do

- update documentation
- potential create wiki
- make it more configurable
  - add credential for SES or Twilio
- make it deployable to more platform
- make the react app more beautiful
